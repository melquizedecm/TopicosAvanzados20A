/*
*source: Programa1.js
*description: funciones iniciales en JS
*encender un motor / apagar un motor
*date: 7/feb/2020
*author: Carlos Gio Rivas
*/
function encender(){
  var motor = document.getElementById("motor");
  motor.innerHTML="<img src='https://i1.wp.com/i3.8000vueltas.com/2007/07/4cyl-animation.gif'>";


  }

function apagar(){
  var motor = document.getElementById("motor");
  motor.innerHTML=" <img src='MotorApagado.jpeg'>";
}
