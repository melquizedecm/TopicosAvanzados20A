var calificacion=[];
for (var i = 0; i < 10; i++) {
  calificacion[i] = prompt("Escribe tu calificacion");
}
alert(calificacion);
